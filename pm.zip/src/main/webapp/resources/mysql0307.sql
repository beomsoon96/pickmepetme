-- 임시 게시글

select * from CARE_COMUNITY